const firebaseConfig = {
  apiKey: "AIzaSyDjVbE7gj-dlFxeXVCvgBPK0WdiQBK4ZqQ",
  authDomain: "adventours-402501.firebaseapp.com",
  databaseURL: "https://adventours-402501-default-rtdb.firebaseio.com",
  projectId: "adventours-402501",
  storageBucket: "adventours-402501.appspot.com",
  messagingSenderId: "419913978490",
  appId: "1:419913978490:web:b57200bf9d04b15a8521c3",
  measurementId: "G-Q5VE5M59WR"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = firebase.database();