const firebaseConfig = {
  apiKey: "AIzaSyDjVbE7gj-dlFxeXVCvgBPK0WdiQBK4ZqQ",
  authDomain: "adventours-402501.firebaseapp.com",
  databaseURL: "https://adventours-402501-default-rtdb.firebaseio.com",
  projectId: "adventours-402501",
  storageBucket: "adventours-402501.appspot.com",
  messagingSenderId: "419913978490",
  appId: "1:419913978490:web:6fc14fb10c50ac848521c3",
  measurementId: "G-BX616K6J6J"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);