<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN LOGIN</title>
    <link rel="stylesheet" href="assets/css/login.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/4.0.0-beta/jquery.min.js"
        integrity="sha512-qFOQ9YFAeGj1gDOuUD61g3D+tLDv3u1ECYWqT82WQoaWrOhAY+5mRMTTVsQdWutbA5FORCnkEPEgU0OF8IzGvA=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <!-- code inserted -->
    <!-- firebase SDK v8.6.8 -->
    <!-- version 10+ not supported -->
    <script src="https://www.gstatic.com/firebasejs/8.6.8/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.6.8/firebase-auth.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.6.8/firebase-database.js"></script>
    <!-- code inserted -->
</head>
<style>
    .portal-title {
    font-size: 3em; /* Adjust the font size as needed */
    text-align: center;
    margin-top: -50px; /* Adjust the top margin as needed */
    margin-bottom: 10px;
    z-index: 1;
    color: white; /* Set the text color to white */
}
</style>
<body>
    <img src="assets/imgs/5.png">
    <h1 class="portal-title">RESTAURANT PORTAL</h1>
    <form class="form" action="assets/php/admin-verify.php" method="POST">  
    <div class="error-message">
        <?php
        if (isset($_GET['error']) && $_GET['error'] == 1) {
            echo "<p>Username or Password is incorrect. Please try again.</p>";
        }
        else if (isset($_GET['error']) && $_GET['error'] == 2)
        {
            echo "<p>User doesn't exists.</p>";
        }
        ?>
    </div>   
        <div class="username">
            <input type="text" name="username" placeholder="Username">
        </div>
        <div class="pass">
        <input type="password" name="password" placeholder="Password">
        </div>
        <div class="submit">
            <input type="submit" name="submit">
        </div>    
    </form>

     <!-- code inserted -->
     <script src="../connection.js"></script>
    <script>
    $(() => {

        // return the user to the dashboard if
        // they are currently logged in

        
        if (localStorage.getItem('user_login') == 'true') {
            location.href = './dashboard.php';
        }

        // handle login function
        function handleLogin(email, password) {
            firebase.auth()
                .signInWithEmailAndPassword(email, password)
                .then((userCredential) => {
                    // Signed in
                    var user = userCredential.user;
                    localStorage.setItem('user_login', 'true');
                    localStorage.setItem('user', JSON.stringify(user));

                    Swal.fire({
                        title: "Success!",
                        text: "Login successfully",
                        icon: "success"
                    }).then(() => {
                        location.href = './dashboard.php';
                    })

                })
                .catch((error) => {
                    // login failed
                    Swal.fire({
                        title: "Error!",
                        text: "Invalid email or password",
                        icon: "error"
                    });
                });
        }


        $('form').submit(function(e) {
            e.preventDefault();
            let urlParams = new URLSearchParams($(this).serialize());
            handleLogin(urlParams.get('email'), urlParams.get('password'));
        })
    })
    </script>
    <!-- end code inserted -->
</body>
</html>