const express = require('express');
const app = express();
const port = 3000; // Choose any available port

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Sample endpoint for handling reservation data
app.post('/api/addReservation', (req, res) => {
    // Your backend logic for handling reservation data goes here
    res.json({ success: true, message: 'Reservation added successfully' });
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
