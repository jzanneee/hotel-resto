<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/Restaurant-Admin/assets/css/_dashboard.css">
    <link rel="stylesheet" href="/Restaurant-Admin/assets/css/style.css">
    <?php require_once './headers.php' ?>

</head>
<body>
    <?php 

$pageTitle = "HELP";
include 'navbar.php';

?>
    <div class="dashboard">
    </div>

    <style>
h1 {
    margin: 20px 0; /* Adjust margin as needed */
    margin-left: 20px;
}
.p {
    margin-bottom: 20px;

}

h2 {
    margin: 30px; /* Adjust margin as needed */
    margin-left: 20px;
}

ul {
    padding-left: 20px; /* Adjust spacing between li elements */
    margin-left: 20px;
    margin-bottom: 70px;
}

li {
    margin-bottom: 10px; /* Adjust spacing between li elements */
}
</style>

    <h1>Privacy Policy</h1>
    <p>At AdvenTours, we understand the importance of privacy, especially for our administrators who play a crucial role in managing our mobile app.
        <p> This privacy policy outlines how we handle your information and your responsibilities as an administrator.</p>

    <h2>Information Collection and Use:</h2>
    <ul>
        <li>As an administrator, you may have access to certain user data for the purpose of app management and support.</li>
        <li>You agree to handle this information confidentially and only use it for authorized purposes related to app administration.</li>
    </ul>

    <h2>Security Measures:</h2>
    <ul>
        <li>We implement robust security measures to protect all user data, including encryption and access controls.</li>
        <li>As an administrator, you are responsible for maintaining the security of your login credentials and reporting any suspicious activity immediately.</li>
    </ul>

    <h2>Data Handling:</h2>
    <ul>
        <li>You agree to handle user data in compliance with relevant privacy laws and regulations.</li>
        <li>Any data access or processing must be done with the user's consent or for legitimate purposes outlined in our Terms of Service.</li>
    </ul>

    <h2>Confidentiality:</h2>
    <ul>
        <li>Any sensitive or proprietary information obtained during app administration must be kept confidential.</li>
        <li>Sharing of such information with unauthorized parties is strictly prohibited and may result in disciplinary action.</li>
    </ul>

    <h2>Compliance with Policies:</h2>
    <ul>
        <li>As an administrator, you are expected to adhere to all policies and guidelines outlined by AdvenTours, including our Terms of Service and Community Standards.</li>
        <li>Failure to comply may result in the termination of your administrator privileges.</li>
    </ul>

    <h2>Reporting and Accountability:</h2>
    <ul>
        <li>You agree to promptly report any breaches of security or misuse of user data to the appropriate authorities within AdvenTours.</li>
        <li>Administrators are accountable for their actions and may be subject to investigation in case of any violations.</li>
    </ul>

    <h2>Training and Awareness:</h2>
    <ul>
        <li>AdvenTours will provide necessary training and resources to ensure administrators understand their responsibilities regarding user privacy and data protection.</li>
        <li>Regular updates and reminders will be provided to keep administrators informed of any changes to policies or regulations.</li>
    </ul>
<ul>                                                                                                                                        
    <p>By accepting your role as an administrator within the AdvenTours mobile app, you acknowledge that you have read, understood, and agree to abide by this privacy policy. Your commitment to maintaining user privacy and data security is essential in upholding our commitment to providing a safe and enjoyable experience for all our users.</p>
    <script>
<body>

<script>

        (() => {
            let state = !0;
            const changeTitle = () => {
                document.title = state ? 'Adventours' : 'Privacy Settings';
                state = !state;
            }
            changeTitle();
            setInterval(() => {
                changeTitle()
            }, 1000)
        })();
    </script>

    
</body>
</html>