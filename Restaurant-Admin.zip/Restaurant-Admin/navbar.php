<!-- =============== __navigation ================ -->
<link rel="stylesheet" href="assets/css/_style.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Roboto&display=swap');
</style>
<style>
* {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
    transition: all 0.3s;
    font-family: 'Roboto', sans-serif;
}

.left-align {
    text-align: left;
    font-weight: bolder;
    margin-top: 25px;
    margin-left: 15px;
}

.rounded-rectangle {
    width: 150px;
    height: 150px;
    background-color: #ffffff;
    border: 1px solid #000000;
    border-radius: 15px;
    padding: 20px;
    float: left;
    margin-top: 20px;
    margin-left: 20px;
    font-weight: bolder;
}

.title {
    font-size: 20px;
    margin-bottom: 40px;
    text-align: center;
}

li a {
    display: flex;
    align-items: start;
    justify-content: start;
}

li a .icon {
    margin-bottom: 10px;
}

li a .title {
    margin-top: 5px;
}

.profile {
    position: relative;
}

.notification-icon {
    position: absolute;
    top: 13px;
    left: 10px; /* Adjust this value as needed */
    border: none;
    background: transparent;
    cursor: pointer;
}

.notification-icon:focus {
    outline: none; /* Remove focus outline */
}

.notification-icon a {
    text-decoration: none; /* Remove underline */
    color: inherit; /* Inherit color from parent */
}
.profile-menu {
  display: none;
  position: absolute;
  background-color: var(--blue);
  color: var(--white);
  margin: 37px 0;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);

}

.profile:hover .profile-menu {
  display: block;
  width: 100%;

}

.profile .notification-icon {
        display: none;
    }
</style>

<div class="_container">
    <div class="__navigation">
        <ul>
            <li style="text-align: center;">
                <a href="#">
                    <div>
                        <img src="assets/imgs/5.png" alt="logo" height="200px" width="200px"
                            style="display: block; margin: 0 auto;">
                    </div>
                </a>
            </li>


            <li class="<?= $pageTitle == 'DASHBOARD' ? 'hovered': null ?>">
            <a href="/Restaurant-Admin/dashboard.php">
                        <span class="icon">
                            <ion-icon name="grid-outline"></ion-icon>                        
                        </span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>


            <li class="<?= $pageTitle == 'RESTO RESERVATIONS' ? 'hovered': null ?>">
                <a href="/Restaurant-Admin/reservation.php">
                        <span class="icon">
                            <ion-icon name="book"></ion-icon>
                        </span>
                        <span class="title">Resto Reservations</span>
                    </a>
                </li>

            <li class="<?= $pageTitle == 'HELP' ? 'hovered': null ?>">
                <a href="/Restaurant-Admin/help.php">
                        <span class="icon">
                            <ion-icon name="help-outline"></ion-icon>
                        </span>
                        <span class="title">Help</span>
                    </a>
                </li>

        </ul>

      
    </div>

    <!-- ========================= Main ==================== -->
    <div class="main">
        <div class="topbar">
            <div class="toggle">
                <ion-icon name="menu-outline"></ion-icon>
            </div>
            <div class="page-header">
                <div class="pagetitle">
                    <div class="submenu mt-3">
                        <?php if (isset($pageTitle) && $pageTitle === "ROOMS"): ?>
                        <p>ROOMS</p>

                        <?php elseif (isset($pageTitle) && $pageTitle === "RESERVATIONS"): ?>
                        <p>RESERVATIONS</p>

                        <?php else: ?>
                        <p><?php echo isset($pageTitle) ? $pageTitle : "DASHBOARD"; ?></p>
                        <?php endif; ?>
                        <!-- Repeat the above structure for other page titles and subpages -->
                    </div>
                </div>

                <div class="profile p-0 pt-3 px-5">
                    <button class="notification-icon">
                    <a href="/Restaurant-Admin/notification.php">
                    <i class="fa-solid fa-bell" style="color: white;"></i>
                    </a>
                    </button>
                    
                <i class="fa-solid fa-user" style="color: white;"></i>
                    <p>ADMINISTRATOR</p>
                    <i class="fa-solid fa-caret-down" style="color: white;"></i>
                    <div class="profile-menu">
                <ul>
                <li onclick="logout()">Logout</li>
                </ul>
            </div>
        </div>
    </div>
 </div>


        <!-- =========== Scripts =========  -->

        <script>
    // Function to handle logout
    function logout() {
        // Remove user login status and redirect to login page
        localStorage.removeItem('user_login');
        localStorage.removeItem('user');
        window.location.href = './index.php';
    }
</script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script>

        // return the user to the dashboard if
        // they are currently logged in
        if (localStorage.getItem('user_login') != 'true') {
            location.href = './index.php';
        }

        function changeSubpageTitle(subpageTitle) {
            $('#subpageTitle').text(subpageTitle);
        }

        let toggle = document.querySelector(".toggle");
        let __navigation = document.querySelector(".__navigation");
        let main = document.querySelector(".main");

        toggle.onclick = function() {
            __navigation.classList.toggle("active");
            main.classList.toggle("active");
        };
        </script>

        <!-- ====== ionicons ======= -->
        <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>