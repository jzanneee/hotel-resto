<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/css/_dashboard.css">
    <link rel="stylesheet" href="assets/css/hover.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer" />
    <?php require_once './headers.php' ?>

</head>
<style>
*

{
    margin: 0;
    padding: 0;
}

body
{
  background-color: #EAEAEA ;
}

.dashboard
{
    padding: 10px;
}

p
{
  text-align: center;
}

.greetings
{
  margin: 20px;
  font-size: 20px;
}

.header
{
  display: flex;
  justify-content: space-between;
  margin: 20px 0;
}

.header .search input[type=text]
{
  border: none;
  border-bottom: 2px solid black;
  width: 100%;
  padding: 10px 20px 10px 0;
  font-size: 14px;
  font-family: FontAwesome;
  font-family: Poppins;
}

input::placeholder {
  font-family: FontAwesome;
}

.header .add-btn button
{
  background-color: #0A142D;
  color: white;
  padding: 10px 20px;
  border-radius: 9px;
}

.announcement
{
    background-color: #E7E161;
    border-radius: 10px;
    display: flex;
    align-items: center; 
}

.announcement .icon
{
    color: #9F9A42;
    font-size: 16px;
    padding: 0 20px 0 20px;
}

.announcement .announcement-txt
{
    width: 70%;
    color: #B0AB55;
}

.announcement .announce-btn button
{
    background: none;
    border: none;
    margin: 20px;
    border-bottom: 2px solid #797531;
}

.total-counts
{
    display: flex;
    justify-content: space-between;
    width: 100%;
}

.confirmed-box, .checkedin-box, .inprogress-box, .onhold-box, .pending-box, .upcoming-box, .completed-box, .cancelled-box, .expired-box, .noshow-box, .rejected-box {
    box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25); 
    border-radius: 9px;
    margin: 3px; 
    padding: 8px;
    color: white;
    font-size: 16px;
    font-weight: bold;
}

.confirmed-box .count, .checkedin-box .count, .inprogress-box .count, .onhold-box .count, .pending-box .count, .upcoming-box .count, .completed-box .count, .cancelled-box .count, .expired-box .count, .noshow-box .count, .rejected-box .count
{
  color: white;
  font-weight: bold;
  font-size: 25px;
  margin: 0px;
}

.confirmed-box
{
    background-color: #30AFBF;
}

.checkedin-box
{
    background-color: #3263B0;
}

.inprogress-box
{
    background-color: #32317C;
}

.onhold-box
{
    background-color: #FC9368;
}

.pending-box
{
    background-color: #94197C;
}

.upcoming-box
{
    background-color: #D26270;
}

.completed-box
{
    background-color: #1F6874;
}

.cancelled-box
{
    background-color: #1E387A
}

.expired-box
{
    background-color: #8B7C7C;
}

.noshow-box
{
    background-color: #4B4F4F;
}

.rejected-box
{
    background-color: #0A142D;
}

/* Style the tabs */
._container {
  width: 100%;
}

.tabs {
  overflow: hidden;
}

.tablink {
  background-color: #f2f2f2;
  float: left;
  width: 33.33%;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 10px;
  transition: background-color 0.3s ease;
}

.tablink:hover {
  background-color: #ddd;
}

.tabcontent {
  display: none;
  padding: 20px;
}

/* Show the current tab */
.tabcontent.active {
  display: block;
}

/* The __modal (background) */
.__modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  }
  
  /* __modal Content */
  .__modal-content {
    position: relative;
    background-color: #fefefe;
    margin: auto;
    padding: 0;
    border: 1px solid #888;
    width: 80%;
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
    -webkit-animation-name: animatetop;
    -webkit-animation-duration: 0.4s;
    animation-name: animatetop;
    animation-duration: 0.4s
  }
  
  /* Add Animation */
  @-webkit-keyframes animatetop {
    from {top:-300px; opacity:0} 
    to {top:0; opacity:1}
  }
  
  @keyframes animatetop {
    from {top:-300px; opacity:0}
    to {top:0; opacity:1}
  }
  
  /* The Close Button */
  .close {
    color: white;
    float: right;
    font-size: 28px;
    font-weight: bold;
  }
  
  .close:hover,
  .close:focus {
    color: #ffffff;
    text-decoration: none;
    cursor: pointer;
  }
  
  .__modal-header {
    padding: 10px;
    background-color: #0A142D;
    color: white;
  }
  
  .__modal-body {
    padding: 20px;}
</style>

<body>
    <?php
    $pageTitle = "DASHBOARD";
    require_once 'navbar.php';
    ?>

<!-- Image -->
<img src="assets/imgs/restaurants.png" alt="logo" 
     style="width: 100%;  margin-bottom: 3%; border-radius: 5px;"
     onmouseover="this..transform='scale(1.1)'"
     onmouseout="this..transform='scale(1)'"> 

</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Date and Clock with AM/PM</title>
    <style>
        #datetime-container {
            text-align: center;
            display: inline-block;
            padding: 10px;
            border-radius: 1px;
            transition: background-color 0.3s ease;
            margin-top: 0%;
           
            width: 100%
        }

        #datetime {
            font-size: 20px;
            font-family: "Courier New", Courier, monospace; 
        }

        #clock {
            font-size: 40px;
            font-family: "Courier New", Courier, monospace; 
        }
    </style>
</head>
<body>

<div id="datetime-container">
    <div id="datetime">
        <div id="date"><?php echo date('l, F j, Y'); ?></div>
        <div id="clock"><?php echo date('h:i:s A'); ?></div>
    </div>
</div>

<script>
    function updateClock() {
        var now = new Date();
        var hours = now.getHours();
        var minutes = now.getMinutes();
        var seconds = now.getSeconds();
        var ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12; // Handle midnight
        hours = String(hours).padStart(2, '0');
        minutes = String(minutes).padStart(2, '0');
        seconds = String(seconds).padStart(2, '0');
        var timeString = hours + ':' + minutes + ':' + seconds + ' ' + ampm;
        document.getElementById('clock').textContent = timeString;
    }

    setInterval(updateClock, 1000);
</script>
</body>
</html>

<div style="margin-top: 20px;">
  </div>
        <div class="total-counts">
            <div class="confirmed-box"style="width: 170px; height: 83px;">
                <p class="count">12</p>
                <p>Confirmed</p>
            </div>
            <div class="checkedin-box"style="width: 170px; height: 83px;">
                 <p class="count">1</p>
                 <p>Checked In</p>
            </div>
            <div class="inprogress-box"style="width: 170px; height: 83px;">
                <p class="count">1</p>
                <p>In Progress</p>
            </div>
            <div class="onhold-box"style="width: 170px; height: 83px;">
                <p class="count">1</p>
                <p>On Hold</p>
            </div>
            <div class="pending-box"style="width: 170px; height: 83px;">
                <p class="count">1</p>
                <p>Pending</p>
            </div>
            <div class="upcoming-box"style="width: 170px; height: 83px;">
                 <p class="count">1</p>
                 <p>Upcoming</p>
            </div>
            <div class="completed-box"style="width: 170px; height: 83px;">
                <p class="count">2</p>
                <p>Completed</p>
            </div>
            <div class="cancelled-box"style="width: 170px; height: 83px;">
                <p class="count">2</p>
                <p>Cancelled</p>
            </div>
            <div class="expired-box"style="width: 170px; height: 83px;">
                <p class="count">41</p>
                <p>Expired</p>
            </div>
            <div class="noshow-box"style="width: 170px; height: 83px;">
                <p class="count">0</p>
                <p>No Show</p>
            </div>
            <div class="rejected-box"style="width: 170px; height: 83px;">
                <p class="count">7</p>
                <p>Rejected</p>
            </div>
</body>
</html>

<body>
<script>
        // Change title
        (() => {
            let state = !0;
            const changeTitle = () => {
                document.title = state ? 'Adventours' : 'Admin Dashboard';
                state = !state;
            }
            changeTitle();
            setInterval(() => {
                changeTitle()
            }, 1000)
        })();
    </script>
</body>
</html>