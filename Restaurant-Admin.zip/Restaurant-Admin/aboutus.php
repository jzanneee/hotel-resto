<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/Restaurant-Admin/assets/css/_dashboard.css">
    <link rel="stylesheet" href="/Restaurant-Admin/assets/css/style.css">
    <?php require_once './headers.php' ?>

</head>
<body>
    <?php 

$pageTitle = "HELP";
include 'navbar.php';

?>
    <div class="dashboard">
    </div>

    <style>

h2 {
    margin: 30px; /* Adjust margin as needed */
    margin-left: 20px;
}

.p {
    margin-bottom: 20px;
}
</style>
            
        <div style="text-align: center;">
    <img src="assets/imgs/4.png" class="logo" height="250px" width="auto">
</div>

            <div style= "text-align: center; margin-top: 20px;">
            <h1> About Us</h1>
            
            <div style= "margin-top: 20px;">
            <p>Welcome to AdvenTours, your buddy to adventures. We are your map in exploring the beauty of Pangasinan. Here's a glimpse of who we are:</p>
            </div>

            <div style= "margin-top: 100px;">
            <div class="story">
                <div style="float: right">
                <img style= "margin-right: 50px; float: right;">
                <img src="assets/imgs/compilation.jpg" class="samplepics" height="300px" width="auto"> 
                </div>
                
                <div style="text-align: left; position: relative;">
    <h2>Our Story</h2>
    <div style="border-bottom: 3px solid black; width: 180px; position: absolute; top: 40px; left: 30px;"></div>
    </div>
                    <div style ="margin-left: 50px; text-align: right">
                    <p>AdvenTours started as our Capstone project founded in 2023 with a simple goal: to empower travelers like you to explore Pangasinan with ease. Most of the members of our team love to explore different places and most of the members wish to travel to Pangasinan. So we decided to create a travel application that helps tourists who want to explore Pangasinan like us.</p>   
                </div>   
            </div>
            <div style="margin-top: 200px">
            </div>

            <div style= "margin-top: 100px;">
            <div class="story">
                <div class="text">
                </div>
                <div style ="text-align: center;">
                    <h2>Meet the Team</h2>
                    <div style ="margin-right: 280px; margin-left: 280px;">
                    <p>Our dedicated team of travel euthusiasts works tirelessly to bring you the best experiences. Get to know the members of the project behind the scenes who make it all happen.</p>   
                </div>   
            </div>
            <div style="margin-top: 50px">
            </div>

            <!DOCTYPE html>
<html>
    <head>
        <title>Adventours</title>
        <link rel="stylesheet" href="css/contact.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">
    </head>
    <body>
        <div class="content">
            <div class="team">
                <h2 class="headers">TEAM</h2>
                    <div class="members">
                        <div class="card">
                            <img src="assets/imgs/justine.jpg">
                            <h5>Justine D. Daguiso</h5>
                            <h6>UX/ UI Designer and Documentation</h6>
                            <div class="connect">
                            <a href="https://www.facebook.com/justine.datu.98?mibextid=ZbWKwL">
                                <i class="fa fa-facebook-f" style="font-size: 15px; padding: 10px;"></i>
                                </a>
                                <a href="https://mail.google.com/mail/u/0/?fs=1&to=daguisojustine@gmail.com&su=Your+email+subject&tf=cm">
                                <i class="material-icons" style="font-size: 15px; padding: 10px;">email</i>
                                </a>
                            </div>
                        </div>
                        <div class="card">
                            <img src="assets/imgs/jhenzen.png">
                            <h5>Jhenzen Anne Gonzales </h5>
                            <h6>UX/ UI Designer, Web Developer and Documentation</h6>
                            <div class="connect">
                            <a href="https://www.facebook.com/jheng.gonzales.90?mibextid=ZbWKwL">
                                <i class="fa fa-facebook-f" style="font-size: 15px; padding: 10px;"></i>
                                </a>
                                <a href="https://mail.google.com/mail/u/0/?fs=1&to=jhenzengonzales15@gmail.com&su=Your+email+subject&tf=cm">
                                <i class="material-icons" style="font-size: 15px; padding: 10px;">email</i>
                                </a>
                                <a href="https://www.instagram.com/jzanneee/?igsh=YzZlODUxMXRtbTJh">
                                <i class="fa-brands fa-instagram" style="font-size: 15px; padding: 10px;"></i>
                                </a>
                            </div>
                        </div>
                        <div class="card">
                            <img src="assets/imgs/paran.jpg">
                            <h5>John Angelo C. Paran </h5>
                            <h6>UX/ UI Designer and Documentation</h6>
                            <div class="connect">
                            <a href="https://www.facebook.com/johnangelo.paran?_rdc=1&_rdr">
                                <i class="fa fa-facebook-f" style="font-size: 15px; padding: 10px;"></i>
                                </a>
                                <a href="https://mail.google.com/mail/u/0/?fs=1&to=johnangelo0929@gmail.com&su=Your+email+subject&tf=cm">
                                <i class="material-icons" style="font-size: 15px; padding: 10px;">email</i>
                                </a>
                            </div>
                        </div>
                        <div class="card">
                            <img src="assets/imgs/trixie.png">
                            <h5>Trixie L. Soriano </h5>
                            <h6>UI/UX Designer, Documentation, Full Stack Mobile Application Developer</h6>
                            <div class="connect">
                                <a href="https://www.facebook.com/trxsrn?_rdc=1&_rdr">
                                <i class="fa fa-facebook-f" style="font-size: 15px; padding: 10px;"></i>
                                </a>
                                <a href="https://mail.google.com/mail/u/0/?fs=1&to=trixielavadiasoriano@gmail.com&su=Your+email+subject&tf=cm">
                                <i class="material-icons" style="font-size: 15px; padding: 10px;">email</i>
                                </a>
                                <a href="https://www.instagram.com/trixsrn/">
                                <i class="fa-brands fa-instagram" style="font-size: 15px; padding: 10px;"></i>
                                </a>
                            </div>
                        </div>
                        <div class="card">
                            <img src="assets/imgs/hanah.jpg">
                            <h5>Hanah Keene Vibiesca</h5>
                            <h6>Web Developer</h6>
                            <div class="connect">
                            <a href="https://www.facebook.com/HKvibiesca?_rdc=1&_rdr">
                                <i class="fa fa-facebook-f" style="font-size: 15px; padding: 10px;"></i>
                                </a>
                                <a href="https://mail.google.com/mail/u/0/?fs=1&to=hanahkeenev@gmail.com&su=Your+email+subject&tf=cm">
                                <i class="material-icons" style="font-size: 15px; padding: 10px;">email</i>
                                </a>
                                <a href="https://www.instagram.com/justme.keene/">
                                <i class="fa-brands fa-instagram" style="font-size: 15px; padding: 10px;"></i>
                                </a>
                            </div>
                        </div>
                    </div>    
                </div>
            </div>
        </div>
    </body>
</html>

<style>
    a {
        color: inherit; 
        text-decoration: none; 
    }

.members {
    display: inline-block;
    justify-content: center;
    align-items: center; 
    margin: 10px;
}

.headers {
    border-bottom: 3px solid #ffc001;
    padding: 5px 5px;
    text-align: center;
    color: #265999;
    margin: 5px auto;
    max-width: 100px;
}
  
.card
{
    padding: 60px;
    text-align: center;
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 20px;
}

.card img
{
    height: 100px;
    width: 100px;
    border: 3px solid #ffc001;
    border-radius: 50px;
}
</style>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <style>
        .contact-box {
            text-align: center;
            padding: 50px;
            background-color: #0A142D;
            transition: background-color 0.3s ease; 
            border-radius: 0px;
            width: 1250px; 
           
        }

        .contact-box h4 {
            color: white; 
        }

        .contact-box p {
            color: white; 
        }
    </style>
</head>
<body>
</script>

<div class="contact-box">
    <h4>C o n t a c t  U s</h4>
    <p>i n q u i r y . a d v e n t o u r s @ g m a i l . c o m</p>
    <p> We're here to assist you. If you have questions, suggestions, or need support, please don't hesitate to get in touch with us.</p>
    
</div>
</body>
</html>